from django.contrib import admin

# Register your models here.
# from accounts.models import CustomUserManager,CustomUser

# admin.site.register(CustomUserManager)
# admin.site.register(CustomUser)